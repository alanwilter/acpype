Contents:
dmp.pdb:    inhibitor for HIV-1 protease from 1BVG.pdb
dmp.mol2:   with charges from YASARA Autosmiles.
AAA.pdb:    a tri alanine peptide with N- and C- termini
AAA.mol2:   in mol2 format
DDD.pdb:    a tri aspartic peptide with N- and C- termini, charge -3
DDD.mol2:   in mol2 format
KKK.pdb:    a tri lysine peptide with N- and C- termini, charge +3
KKK.mol2:   in mol2 format
FFF.pdb:    a tri phenylalanine peptide with N- and C- termini, aromatic
FFF.mol2:   in mol2 format
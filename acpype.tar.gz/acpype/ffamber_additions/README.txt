FF.dat : updated FF.dat file to include all forcefield prefixes for ffamber
[spc, spce, tip3p, ions].itp : modified versions to include _FF_AMBER** definitions